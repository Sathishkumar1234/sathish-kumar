from flask import Flask, jsonify, request
import json

app = Flask(__name__)

# Create a sample in-memory data store
data = []

@app.route('/api/data', methods=['POST'])
def create_data():
    # Retrieve the JSON data from the request body
    new_data = request.get_json()

    try:
        with open('data.json', 'w') as json_file:
            json.dump(new_data, json_file)
        return 'JSON file created successfully'
    except Exception as e:
        return f'An error occurred: {str(e)}'


    # Return a JSON response with the newly created data
    return jsonify(new_data), 201

if __name__ == '__main__':
    app.run()
