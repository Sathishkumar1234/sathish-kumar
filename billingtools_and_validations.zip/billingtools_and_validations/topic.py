import json
import os
import requests
from database import Database
from string import Template
import traceback
from flask import jsonify, make_response
import subprocess
import paramiko
from io import StringIO

class Topic:
    def __init__(self, data, basedir):
        self.data = data
        self.topic_name = None
        self.query_name = None
        self.topic_data = None
        self.query_data = None
        self.basedir = basedir

    @staticmethod
    def read_all_topics(basedir):
        topics = {}
        for root, dirs, files in os.walk(r"C:\\Users\\sathi\\Downloads\\billingtools_and_validations\\topics"):
            for filename in files:
                queries = []
                if filename != 'log_check':
                    with open(r"C:\\Users\\sathi\\Downloads\\billingtools_and_validations\\topics\\" + filename) as f:
                        # print(f)
                        try:
                            topic_data = json.load(f)
                        except:
                            traceback.print_exc()
                            return "Topic definition error: " + filename

                        for query, value in topic_data.items():
                            if value :
                                queryv = {"query": query,
                                        "params": value['input_params'],
                                        "server_name": value
                                        }
                                queries.append(queryv)
                            else :
                                aqueryv = {"query": query,
                                            "params": value['input_params']
                                        }
                                queries.append(queryv)
                        topics[filename] = {'queries': queries}
        return topics

    def read_all_log_topics(basedir):
        topics = {}
        for root, dirs, files in os.walk("/opt/billing_tools" + "/topics"):
            for filename in files:
                queries = []
                if filename == 'log_check':
                    with open('/opt/billing_tools' + '/topics/' + filename) as f:
                        # print(f)
                        try:
                            topic_data = json.load(f)
                        except:
                            traceback.print_exc()
                            return "Topic definition error: " + filename

                        for query, value in topic_data.items():
                            # print("value", value)
                            queryv = {"query": query,
                                      "params": value['issue_types']}
                            queries.append(queryv)
                        topics[filename] = {'queries': queries}
        return topics
    def _validate_data(self):
    
        if 'topic' in self.data:
            self.topic_name = self.data['topic']
        else:
            return 'Topic not specified'

        if 'query' in self.data:
            self.query_name = self.data['query']
        else:
            return 'Query not specified'

        with open(self.basedir + '/topics/' + self.topic_name) as f:
            self.topic_data = json.load(f)

        if self.query_name not in self.topic_data:
            return "Query not defined in topic: " + self.query_name
        self.query_data = self.topic_data[self.query_name]

        for iparam in self.query_data['input_params']:
            if iparam not in self.data:
                return "Input param " + iparam + " missing"

        return "Pass"
    

    def run_query(self):
        ret = self._validate_data()
        if ret != 'Pass':
            return ret

        db_conns = {}
        results = []
        for query in self.query_data['state_queries']:
            state = query['state_name']
            db_name = query['db_name']
            if db_name not in db_conns:
                db_conn = Database(query['repo_name'],
                                   'billing_tool', 'access', db_name)
                ret = db_conn.connect()
                if ret != "Success":
                    return "Connection to " + query['repo_name'] + " failed"
                db_conns[db_name] = db_conn
            else:
                db_conn = db_conns[db_name]
            try:
                qresult = db_conn.run_query(query['query'], self.data)
            except:
                results.append(
                    {'state_name': state, 'status': "Could not run query"})
                traceback.print_exc()
                return results

            qresult['status'] = 'success'
            results.append(
                {'state_name': state, 'status': 'success', 'result': qresult})
            if 'out_params' in query and len(query['out_params']) != 0:
                if len(qresult['entries']) == 0:
                    return "Could not extract out params from query: " + state
                for out_param in query['out_params']:
                    opindex = qresult['fields'].index(out_param)
                    self.data[out_param] = qresult['entries'][0][opindex]

        for db_name, db_conn in db_conns.items():
            db_conn.close()

        return results
