from flask import Flask
import json

app = Flask(__name__)
data=[]

# Sample data to be stored in the JSON file
data = [
    {
        'id': 1,
        'name': 'John Doe',
        'age': 30
    },
    {
        'id': 2,
        'name': 'Jane Smith',
        'age': 25
    }
]

# Endpoint to create the JSON file
@app.route('/create_json_file',methods=["POST"])
def create_json_file():
    try:
        with open('data.json', 'w') as json_file:
            json.dump(data, json_file)
        return 'JSON file created successfully'
    except Exception as e:
        return f'An error occurred: {str(e)}'

if __name__ == '__main__':
    app.run(debug=True)
