import mysql.connector
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sathish21"
)
mycursor = mydb.cursor()
try:
   
    mycursor.execute("CREATE DATABASE jsondata")
    print("create databse")
    
except:
    print("not create database")

