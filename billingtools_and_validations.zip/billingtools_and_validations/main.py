import sys
import requests
import json
import random
from app import app
from flask import Flask, flash, request, jsonify
from topic import Topic
import pathlib
from cjsonencoder import CustomJSONEncoder

app.json_encoder = CustomJSONEncoder

basedir = "C:\\Users\\sathi\\Downloads\\billingtools_and_validations\\"
curdir = str(pathlib.Path(__file__).parent.absolute())

@app.route('/get_topics', methods=['GET'])
def get_topics():
    rettopics = Topic.read_all_topics(basedir)
    if isinstance(rettopics, str):
        ret = {"status": rettopics}
    else:
        ret = {"status": "success", "result": rettopics}

    return ret

@app.route('/run_query', methods=['POST'])
def run_query():
    data = request.json

    topic = Topic(data, basedir)
    results = topic.run_query()
    if isinstance(results, str):
        ret = {"status": results}
    else:
        ret = {"status": "success", "result": results}
    print("print query results %s" % (results))
    return ret
    

if __name__ == '__main__':
    if len(sys.argv) > 1:
        basedir = sys.argv[1]

    app.run()
